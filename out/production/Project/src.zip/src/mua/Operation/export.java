package src.mua.Operation;
import src.mua.Data;
import src.mua.MyError;
import src.mua.NameSpace;

import java.util.HashMap;

public class export extends Operation{
    public export(){
        name = "export";
        hasReturnValue = false;
        arg_num = 0;
    }
    public void exec(NameSpace space) throws MyError{
        HashMap<String, Data>allName = space.thisSpaceAllName();
        //System.out.println("export");
        for (String name: allName.keySet()){
            //System.out.println(name + " " + allName.get(name));
            space.mainSpacePutName(name, allName.get(name));
        }
    }
}
